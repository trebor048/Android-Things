SKIPUNZIP=1

# ViPER4Android™ 2.5.0.5 operations
# gh

unzip -qqo "$ZIPFILE" module.prop -d $MODPATH >&2
unzip -qqo "$ZIPFILE" functions -d $TMPDIR >&2

source $TMPDIR/functions

go
