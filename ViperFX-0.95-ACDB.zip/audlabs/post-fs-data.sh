
# Switch SELinux to Permissive Mode:

(
  selinux=`getenforce`
  if [ "$selinux" == "Enforcing" ]; then
    setenforce 0 2>/dev/null
  fi
)&
