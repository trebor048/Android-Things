#!/system/bin/sh
# Force close and restart V4A at every boot
sleep 9
am force-stop com.pittvandewitt.viperfx
sleep 3
am start -n com.pittvandewitt.viperfx/.MainActivity
sleep 3
am start -a android.intent.action.MAIN -c android.intent.category.HOME
