ui_print " "

# info
MODVER=`grep_prop version $MODPATH/module.prop`
MODVERCODE=`grep_prop versionCode $MODPATH/module.prop`
ui_print " ID=$MODID"
ui_print " Version=$MODVER"
ui_print " VersionCode=$MODVERCODE"
ui_print " MagiskVersion=$MAGISK_VER"
ui_print " MagiskVersionCode=$MAGISK_VER_CODE"
ui_print " "

# .aml.sh
mv -f $MODPATH/aml.sh $MODPATH/.aml.sh

# cleaning
ui_print "- Cleaning..."
rm -f $MODPATH/LICENSE
ui_print " "

# force 32
if getprop | grep -Eq "hires.32\]: \[1"; then
  ui_print "- Forcing to 32 bit instead of 24 bit..."
  sed -i 's/#h//g' $MODPATH/.aml.sh
  sed -i 's/#h//g' $MODPATH/service.sh
  sed -i 's/enforce_mode 24/enforce_mode 32/g' $MODPATH/service.sh
  sed -i 's/24 bit/32 bit/g' $MODPATH/module.prop
  sed -i 's/24 Bit/32 Bit/g' $MODPATH/module.prop
  ui_print " "
fi

# speaker 16
if getprop | grep -Eq "speaker.16\]: \[1"; then
  ui_print "- Forcing speaker to 16 bit..."
  sed -i 's/#s//g' $MODPATH/.aml.sh
  ui_print " "
fi

# permission
ui_print "- Setting permission..."
FOLDER=`find $MODPATH/system/vendor -type d`
for FOLDERS in $FOLDER; do
  chown 0.2000 $FOLDERS
done
if [ "$API" -gt 25 ]; then
  chcon -R u:object_r:vendor_file:s0 $MODPATH/system/vendor
  chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/etc
  chcon -R u:object_r:vendor_configs_file:s0 $MODPATH/system/vendor/odm/etc
fi
ui_print " "



