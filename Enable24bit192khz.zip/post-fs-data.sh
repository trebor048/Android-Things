mount -o rw,remount /data
MODDIR=${0%/*}

# etc
if [ -d /sbin/.magisk ]; then
  MAGISKTMP=/sbin/.magisk
else
  MAGISKTMP=`find /dev -mindepth 2 -maxdepth 2 -type d -name .magisk`
fi
ETC=$MAGISKTMP/mirror/system/etc
VETC=$MAGISKTMP/mirror/vendor/etc
VOETC=$MAGISKTMP/mirror/vendor/odm/etc
MODETC=$MODDIR/system/etc
MODVETC=$MODDIR/system/vendor/etc
MODVOETC=$MODDIR/system/vendor/odm/etc

# audio policy
FILE="*policy*.conf *policy*.xml"
rm -f `find $MODDIR/system -type f -name *policy*`
for FILES in $FILE; do
  AP=`find $ETC -maxdepth 1 -type f -name $FILES`
  VAP=`find $VETC -maxdepth 1 -type f -name $FILES`
  VAP2=`find $VETC/audio -maxdepth 1 -type f -name $FILES`
  VAP3=`find $VOETC -maxdepth 1 -type f -name $FILES`
  cp -f $AP $MODETC
  cp -f $VAP $MODVETC
  cp -f $VAP2 $MODVETC/audio
  cp -f $VAP3 $MODVOETC
done

# audio platform info
FILE=*audio*platform*info*.xml
rm -f `find $MODDIR/system -type f -name $FILE`
API=`find $ETC -maxdepth 1 -type f -name $FILE`
VAPI=`find $VETC -maxdepth 1 -type f -name $FILE`
cp -f $API $MODETC
cp -f $VAPI $MODVETC

# run
sh $MODDIR/.aml.sh





